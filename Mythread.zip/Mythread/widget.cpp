#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QTimer>
#include <QDateTime>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    connect(&thread,SIGNAL(sendMessage(QString)),this,SLOT(GetPthreadMessage(QString)));
    QTimer *timer = new QTimer(this);
    ui->lcdNumber->setDigitCount(19);
    ui->lcdNumber->display(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"));
    connect(timer,SIGNAL(timeout()),this,SLOT(chTime()));
    timer->start(1000);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::GetPthreadMessage(QString recv)
{
    ui->lineEdit->setText(recv);
    qDebug() << recv;
}

void Widget::on_StartPthread_clicked()
{
    thread.start(); //�ͻ���� MyThread���run����
    ui->StartPthread->setEnabled(false);
    ui->StopPthread->setEnabled(true);
}

void Widget::on_StopPthread_clicked()
{
    if(thread.isRunning())
    {
        thread.stop(); //�ͻ���� MyThread���stop����
        ui->StartPthread->setEnabled(true);
        ui->StopPthread->setEnabled(false);
    }
}

void Widget::chTime()
{
    ui->lcdNumber->display(QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"));
}
