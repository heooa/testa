#ifndef MYTHREAD_H
#define MYTHREAD_H

#include <QThread>

class Mythread : public QThread
{
    Q_OBJECT
public:
    explicit Mythread(QObject *parent = 0);

    void run();
    void stop();
    bool stopped;
    QString myString;
    
signals:
    void sendMessage(QString);//sendMessageΪ�Զ����ź�
    
public slots:
    
};

#endif // MYTHREAD_H
