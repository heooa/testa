#include "mythread.h"
#include <QDebug>

Mythread::Mythread(QObject *parent) :
    QThread (parent)
{
}

void Mythread::run()
{
    qreal i =0;
    while(!stopped)
    {
        qDebug()<<QString("in MyThread:%1").arg(i++);
        myString = QString("in MyThread:%1").arg(i++);
        emit sendMessage(myString);
        this->msleep(100); //�������msleep�Ⱥ�����ʱ��������Ῠס.
    }
    stopped=!stopped;
}

void Mythread::stop()
{
    stopped = true;
}
